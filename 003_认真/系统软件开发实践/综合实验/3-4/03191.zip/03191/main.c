/*
 * @Author: Chen
 * @Date: 2022-03-19 09:39:41
 * @LastEditTime: 2022-05-09 17:17:22
 * @FilePath: \03191\main.c
 */
#include "fb3-2.h"
#include <stdio.h>
int main(){
    char* ans = do_cal("let avg(a, b){(a + b) / 2;}\n");

    printf("The ans is %s\n", ans);
    ans = do_cal("avg(1, 4);\n");
    printf("The ans is %s\n", ans);
    
}




